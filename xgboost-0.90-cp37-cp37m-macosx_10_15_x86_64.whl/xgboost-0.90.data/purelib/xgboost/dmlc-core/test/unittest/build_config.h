#define CMAKE_CURRENT_SOURCE_DIR "/Users/chyunsu/Desktop/xgboost/dmlc-core/test/unittest"

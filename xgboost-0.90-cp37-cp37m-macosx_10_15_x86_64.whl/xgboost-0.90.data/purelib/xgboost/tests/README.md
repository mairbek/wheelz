This folder contains testcases for xgboost.
